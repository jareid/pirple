def Artist(): 
	return "Tupac";

def Genre(): 
	return "Rap";

def Duration(isMins): 
	if isMins":
		return 5;
	else:
		return 301


print(Artist())
print(Genre())
print(Duration(True))
print(Duration(False))

