"""
The following lines create variables containing metadata
about a song
""" 
Artist = "Tupac"            # The artist (string)
Genre = "Hip-Hop"           # The genre  (string)
Title = "Life Goes On"      # The song title (string)
DurationInSeconds = 301     # The length of  the song in seconds (integer)
Album = "All Eyez On Me"    # The album name (string)
AlbumArtist = "Tupac"       # The album artist (string)
FileSizeMB = 11.5           # the filesize in megabytes (float)
Year = 2001                 # the year the song came out (integer)
Rating = 4.5                # the rating out of 5 (float)


"""
The following lines print out 
the created variables
"""
print(Artist)
print(Genre)
print(Title)
print(DurationInSeconds)
print(Album)
print(AlbumArtist)
print(FileSizeMB)
print(Year)
print(Rating)
