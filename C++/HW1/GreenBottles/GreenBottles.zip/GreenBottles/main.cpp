#include <iostream>

using namespace std;

int main()
{
    int greenBottles = 10;
    cout << "There were " << greenBottles << " green bottles" << endl;
    greenBottles--;
    cout << "There were " << greenBottles << " green bottles" << endl;

    return 0;
}
