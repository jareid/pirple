// The following lines create variables containing metadata about a song
Artist = "Tupac"            // The artist (string)
Genre = "Hip-Hop"           // The genre  (string)
Title = "Life Goes On"      // The song title (string)
DurationInSeconds = 301     // The length of  the song in seconds (integer)
Album = "All Eyez On Me"    // The album name (string)
AlbumArtist = "Tupac"       // The album artist (string)
FileSizeMB = 11.5           // the filesize in megabytes (float)
Year = 2001                 // the year the song came out (integer)
Rating = 4.5                // the rating out of 5 (float)


// The following lines console.log out the created variables

console.log(Artist)
console.log(Genre)
console.log(Title)
console.log(DurationInSeconds)
console.log(Album)
console.log(AlbumArtist)
console.log(FileSizeMB)
console.log(Year)
console.log(Rating)
